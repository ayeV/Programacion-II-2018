using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


//no hace falta agregar la referencia de la clase sellada
namespace Entidades
{
  public static class Extensora
  {

    // para que se le indique que este metodo se agregara a una clase en particular, hay que indicarle cual va a ser la instancia a la que se agregara

    public static string ObtenerDatos(this Entidades.Externa.Sellada.PersonaExternaSellada tipo)
    {
      return string.Format("{0} {1} {2} {3}", tipo.Nombre, tipo.Apellido, tipo.Edad, tipo.Sexo);
    }


    public static bool EsNulo(this Object obj)
    {
      bool retorno = false;
      if (obj.Equals(null))
      {
        retorno = true;
      }
      return retorno;
    }

    public static int CantidadDigitos(this Int32 numero)
    {
      string numeroString = numero.ToString();

      return numeroString.Length;

    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="numero1"></param>
    /// <param name="numero2">representa la cantidad de digitos</param>
    /// <returns></returns>
    public static bool TieneLaMismaCantidadDeDigitos(this Int32 numero1, Int32 numero2)
    {
      bool retorno = false;
      if (numero1.CantidadDigitos() == numero2)
      {
        retorno = true;
      }
      return retorno;
    }

    public static List<Persona> TraerDB(this Entidades.Persona p)
    {
      SqlConnection connection = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand command = new SqlCommand();
      command.CommandText = "SELECT * FROM  Personas";
      command.CommandType = CommandType.Text;
      command.Connection = connection;
      List<Persona> personas = new List<Persona>();
      try
      {
        connection.Open();

        SqlDataReader lector = command.ExecuteReader();
        while (lector.Read())
        {
          personas.Add(new Persona(lector.GetString(1), lector.GetString(2), lector.GetInt32(3), (ESexo)lector.GetInt32(4)));
        }

        connection.Close();
      }
      catch (Exception e)
      {
        throw e;
      }

      return personas;
    }

    public static bool AgregarDB(this Persona p)
    {
      bool retorno = false;
      SqlConnection connection = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand command = new SqlCommand();
      command.CommandText = string.Format("INSERT INTO Personas values ('{0}','{1}',{2},{3})",p.Nombre,p.Apellido,p.Edad,(int)p.Sexo);
      command.CommandType = CommandType.Text;
      command.Connection = connection;

      try
      {
        connection.Open();
        command.ExecuteNonQuery();
        connection.Close();
       
        retorno = true;
      }
      catch (Exception e)
      {
        throw e;
        retorno = false;
      }

      return retorno;
    }

    public static bool QuitarDB(this Persona p, int id)
    {
      bool retorno = false;
      SqlConnection connection = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand command = new SqlCommand();
      command.CommandText = string.Format("DELETE  Personas  WHERE id = {0}",id);
      command.CommandType = CommandType.Text;
      command.Connection = connection;

      try
      {
        connection.Open();
        command.ExecuteNonQuery();
        connection.Close();

        retorno = true;
      }
      catch (Exception e)
      {
        throw e;
        retorno = false;
      }

      return retorno;
    }

    public static bool ModificarDB(this Persona p, int id)
    {
      bool retorno = false;
      SqlConnection connection = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand command = new SqlCommand();
      command.CommandText = string.Format("UPDATE Personas SET nombre = '{0}', apellido = '{1}', edad = {2}, sexo = {3} WHERE id = {4}",p.Nombre,p.Apellido,p.Edad,(int)p.Sexo,id );
      command.CommandType = CommandType.Text;
      command.Connection = connection;

      try
      {
        connection.Open();
        command.ExecuteNonQuery();
        connection.Close();

        retorno = true;
      }
      catch (Exception e)
      {
        throw e;
        retorno = false;
      }

      return retorno;
    }

  }
}
