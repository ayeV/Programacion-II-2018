using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Externa;

namespace Entidades
{
  public class PersonaExternaHeredada : PersonaExterna
  {
    public PersonaExternaHeredada(string nombre, string apellido, int edad, Entidades.Externa.ESexo sexo) :base(nombre,apellido,edad,sexo)
    {

    }

    

    public string Nombre
    {
      get { return base._nombre; }
    }

    public string Apellido
    {
      get { return base._apellido; }
    }

    public int Edad
    {
      get { return base._edad; }
    }

    public Entidades.Externa.ESexo Sexo
    {
      get { return base._sexo; }
    }

    public string ObtenerDatos()
    {
      return string.Format("{0} {1} {2} {3}", this.Nombre, this.Apellido, this.Edad, this.Sexo);
    }

  }
}
