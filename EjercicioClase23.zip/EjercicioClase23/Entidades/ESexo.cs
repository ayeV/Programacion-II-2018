public enum ESexo { Masculino,Femenino,Indeterminado};
