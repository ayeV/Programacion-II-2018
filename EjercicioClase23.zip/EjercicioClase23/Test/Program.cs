using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
using Entidades.Externa;
using Entidades.Externa.Sellada;
namespace Test
{
  class Program
  {
    static void Main(string[] args)
    {
      Persona p1 = new Persona("Juan", "Perez", 87, ESexo.Masculino);


      //Console.WriteLine("{0} {1} {2} {3}", p1.Nombre, p1.Apellido, p1.Edad, p1.Sexo);
      Console.WriteLine(p1.ObtenerDatos());

      PersonaExterna p2 = new PersonaExterna("Pepe", "Gomez", 54, Entidades.Externa.ESexo.Masculino);
      //para generar codigo fuente de algo que no es mio, lo heredo y asi podre acceder a sus atributos

      PersonaExternaHeredada p3 = new PersonaExternaHeredada("Pepe", "Gomez", 54, Entidades.Externa.ESexo.Masculino);
      Console.WriteLine(p3.ObtenerDatos());
      //Console.WriteLine("{0} {1} {2} {3}", p3.Nombre, p3.Apellido, p3.Edad, p3.Sexo);

      PersonaExternaSellada p4 = new PersonaExternaSellada("Ana", "Gonzales", 56, Entidades.Externa.Sellada.ESexo.Femenino);
     // Console.WriteLine(Extensora.ObtenerDatos(p4));
      Console.WriteLine(p4.ObtenerDatos());

      Console.WriteLine("Es nulo: {0}", p4.EsNulo());

      int numero = 453;
      Console.WriteLine("La cantidad de digitos de {0} es {1}", numero, numero.CantidadDigitos());
      int cantDigitos = 5;
     if(numero.TieneLaMismaCantidadDeDigitos(cantDigitos))
      {
        Console.WriteLine("{0} tiene la misma cantidad de digitos", cantDigitos);

      }
     else
      {
        Console.WriteLine( "No tienen la misma cant de digitos");
      }

      List<Persona> personas = p1.TraerDB();
      foreach (Persona item in personas)
      {
        Console.WriteLine(item.ObtenerDatos());
      }

      Persona p5 = new Persona("Juanaaa", "perez", 56, ESexo.Femenino);
      //if(p5.AgregarDB())
      //{
      //  Console.WriteLine("Persona agregada");
      //}
      //else
      //{
      //  Console.WriteLine("No se pudo agregar la persona");
      //}

      //if(p1.QuitarDB(7))
      //{
      //  Console.WriteLine("Persona con ID 7 eliminada");
      //}
      //else

      //{
      //  Console.WriteLine("No se pudo eliminar a la persona con id 7");
      //}
      Persona pModifcada = new Persona("Jose", "Perez", 65, ESexo.Masculino);
      Extensora.ModificarDB(pModifcada, 10);
      //if(p1.ModificarDB(10))
      //{
      //  Console.WriteLine("Persona modificada");
      //}
      //else
      //{
      //  Console.WriteLine("No se pudo modificar");
      //}

      Console.ReadLine();

    }
  }
}
