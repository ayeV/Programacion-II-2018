using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace EjercicioClase18
{
  public static class AdministradorArchivos
  {
  public static bool Escribir(string path, string datos)
    {
      bool retorno;
      try
      {
        using (StreamWriter sw = new StreamWriter(path,false))
        {
          sw.WriteLine(datos);
          retorno = true;
        }
      }
      catch (Exception )
      {

        retorno = false;
      }

      return retorno;

    }

  public static bool Leer(string path, out string datos)
    {
      bool retorno;
      datos = "";
      try
      {
          StreamReader sr = new StreamReader(path, true);
          datos = sr.ReadToEnd();
          retorno = true;

      }
      catch (Exception)
      {

        retorno = false;
      }

      return retorno;

    }
  }
}
