using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EjercicioClase18;
namespace TestEjercicioClase18
{
  class Program
  {
    static void Main(string[] args)

    {
      string valor = "";

      //if (AdministradorArchivos.Escribir(@"C: \Users\alumno\Desktop\Valdez.Ayelen.2A.Clases\EjercicioClase18\archivo.txt", "pepe\r"))
      //{
      //  Console.Write("Archivo escrito con exito");
      //}
      //else
      //{
      //  Console.WriteLine("El archivo no se pudo escribir\n");
      //}

      //if(AdministradorArchivos.Leer(@"C:\Users\alumno\Desktop\Valdez.Ayelen.2A.Clases\EjercicioClase18\archivo.txt",out valor))
      //{
      //  Console.WriteLine("Archivo leido con exito\n");
      //  Console.Write(valor);
      //}
      //else
      //{
      //  Console.WriteLine("No se pudo leer el archivo");
      //}

      //if (AdministradorArchivos.Escribir(@"C:\Users\alumno\Desktop\archivo.txt", "pepe\r"))
      //{
      //  Console.Write("Archivo escrito con exito");
      //}
      //else
      //{
      //  Console.WriteLine("El archivo no se pudo escribir\n");
      //}

      //if (AdministradorArchivos.Leer(@"C:\Users\alumno\Desktop\archivo.txt", out valor))
      //{
      //  Console.WriteLine("Archivo leido con exito\n");
      //  Console.Write(valor);
      //}
      //else
      //{
      //  Console.WriteLine("No se pudo leer el archivo");
      //}



      //if (AdministradorArchivos.Escribir(@" D:\Mis Documentos\archivo.txt", "pepe\r"))
      //{
      //  Console.Write("Archivo escrito con exito");
      //}
      //else
      //{
      //  Console.WriteLine("El archivo no se pudo escribir\n");
      //}

      //if (AdministradorArchivos.Leer(@" D:\Mis Documentos\archivo.txt", out valor))
      //{
      //  Console.WriteLine("Archivo leido con exito\n");
      //  Console.Write(valor);
      //}
      //else
      //{
      //  Console.WriteLine("No se pudo leer el archivo");
      //}


      if (AdministradorArchivos.Escribir(Environment.GetFolderPath(Environment.SpecialFolder.Desktop)+"\\archivo.txt", "pepe\r"))
      {
        Console.Write("Archivo escrito con exito\n");
      }
      else
      {
        Console.WriteLine("El archivo no se pudo escribir\n");
      }

      if (AdministradorArchivos.Leer(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) +"\\archivo.txt" , out valor))
      {
        Console.WriteLine("Archivo leido con exito\n");
        Console.Write(valor);
      }
      else
      {
        Console.WriteLine("No se pudo leer el archivo\n");
      }
      //Lo guarda y lee en donde esta el .exe
      if (AdministradorArchivos.Escribir(AppDomain.CurrentDomain.BaseDirectory + "\\archivo.txt", "pepe\r"))
      {
        Console.Write("Archivo escrito con exito\n");
      }
      else
      {
        Console.WriteLine("El archivo no se pudo escribir\n");
      }

      if (AdministradorArchivos.Leer(AppDomain.CurrentDomain.BaseDirectory + "\\archivo.txt", out valor))
      {
        Console.WriteLine("Archivo leido con exito\n");
        Console.Write(valor);
      }
      else
      {
        Console.WriteLine("No se pudo leer el archivo\n");
      }

      Console.ReadLine();
        

    }
  }
}
