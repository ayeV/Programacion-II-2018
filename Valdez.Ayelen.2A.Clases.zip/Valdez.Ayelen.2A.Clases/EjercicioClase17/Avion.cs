using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase17
{
  public class Avion : Vehiculo, IAFIP,IARBA
  {

   protected double _velocidadMaxima;

    public Avion(double precio, double velocidad) :base(precio)
    {
      this._velocidadMaxima = velocidad;

    }

    public int PropiedadInt
    { get { return 0; }
    
    }
    public double PropiedadDouble
    {
      get { return this._velocidadMaxima; }
      
    }

     double IAFIP.CalcularImpuesto()
    {
      double retorno = 0;
      return retorno = this._precio * 33 / 100;
  
    }

    double IARBA.CalcularImpuesto()
    {
      double retorno = 0;
      return retorno = this._precio * 27 / 100;
    }
  }
}
