using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase17
{
    public class Comercial : Avion,IARBA //agrego IARBA porque sino tira error de compilacion
    {
        protected int _capacidadPasajeros;


        public int CapacidadPasajeros
        {
            get { return this._capacidadPasajeros; }
        }
        public Comercial(double precio, double velocidad, int capacidad) : base(precio, velocidad)
        {
            this._capacidadPasajeros = capacidad;
        }



        double IARBA.CalcularImpuesto()
        {
            double retorno = 0;
            return retorno = this._precio * 25 / 100;
        }

    }
}
