using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase17
{
  public interface IAFIP
  {

    int PropiedadInt
    {
      get;
     
    }

    double PropiedadDouble
    {
      get;
     
    }



    double CalcularImpuesto();
  }
}
