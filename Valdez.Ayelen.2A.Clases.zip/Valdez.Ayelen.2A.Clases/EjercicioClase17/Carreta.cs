using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase17
{
public  class Carreta :Vehiculo,IARBA
  {

    public Carreta(double precio) :base(precio)
    {

    }

    public double CalcularImpuesto()
    {
      double retorno = 0;
      return retorno = this._precio * 18/ 100;
    }
  }
}
