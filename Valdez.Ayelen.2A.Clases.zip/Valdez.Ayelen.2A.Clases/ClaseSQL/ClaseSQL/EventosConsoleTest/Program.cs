using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades1;

namespace EventosConsoleTest
{
  class Program
  {
    static void Main(string[] args)
    {

      Televisor tv1 = new Televisor(447, "Sony", 14500, 50, "China");
      //estoy indicando la dir de memoria del metodo que tiene que ejecutar
      //agrego un metodo al evento
      tv1.MiEvento += new MiDelegado(PruebaEvento); 
      tv1.MiEvento += new MiDelegado(new Program().PruebaEvento1);
      tv1.EventoTv += new DelegadoTV(PruebaEvento2);

      //tv1.MiEvento += new MiDelegado(PruebaEvento);
      //tv1.MiEvento += new MiDelegado(new Program().PruebaEvento1);
      //tv1.EventoTv += new DelegadoTV(PruebaEvento2);

      //tv1.MiEvento += new MiDelegado(PruebaEvento);
      //tv1.MiEvento += new MiDelegado(new Program().PruebaEvento1);
      //tv1.EventoTv += new DelegadoTV(PruebaEvento2);

      //tv1.MiEvento += new MiDelegado(PruebaEvento);
      //tv1.MiEvento += new MiDelegado(new Program().PruebaEvento1);
      //tv1.EventoTv += new DelegadoTV(PruebaEvento2);

      tv1.Insertar();

      Console.ReadKey();
    }

    public static void PruebaEvento()
    {
      Console.WriteLine("Se inserto un registro en la base de datos");

    }

    public void PruebaEvento1()
    {
      Console.WriteLine("Se inserto un registro en la base de datos....");
    }

    public static void PruebaEvento2(Televisor televisor, TVEventsArgs ev)
    {
      Console.WriteLine("{0}-{1}-{2}-{3}-{4}-{5}", televisor.id, televisor.marca, televisor.precio, televisor.pulgadas, televisor.pais,ev.Fecha);
    }

  }
}
