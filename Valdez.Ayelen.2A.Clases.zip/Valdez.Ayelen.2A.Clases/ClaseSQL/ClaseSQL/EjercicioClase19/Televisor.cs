using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Serialization;


namespace EjercicioClase19
{
  public class Televisor
  {
    public int id;
    public string marca;
    public double precio;
    public int pulgadas;
    public string pais;

    public Televisor()
    {

    }


    public Televisor(int id, string marca, double precio, int pulgadas, string pais)
    {
      this.id = id;
      this.marca = marca;
      this.precio = precio;
      this.pulgadas = pulgadas;
      this.pais = pais;
    }

    public bool Insertar()
    {
      bool retorno = false;

      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

      SqlCommand comando = new SqlCommand();
      comando.CommandText = string.Format("INSERT INTO Televisores values ({0},'{1}',{2},{3},'{4}')", this.id, this.marca, this.precio, this.pulgadas, this.pais);
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;

      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
        retorno = true;
      }
      catch (Exception)
      {

        retorno = false;
      }

      return retorno;
    }



    public static bool Modificar(Televisor tv)
    {
      bool retorno = true;

      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand comando = new SqlCommand();
      comando.CommandText = string.Format("UPDATE Televisores SET  marca = '{0}',precio = {1}, pulgadas  = {2},pais = '{3}' WHERE codigo = {4}", tv.marca, tv.precio, tv.pulgadas, tv.pais, tv.id);
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;



      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();

      }
      catch (Exception)
      {

        retorno = false;
      }

      return retorno;

    }

    public static bool Borrar(Televisor tv)
    {
      bool retorno = true;
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand comando = new SqlCommand();
      comando.CommandText = string.Format("DELETE Televisores WHERE codigo = {0}", tv.id);
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;



      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();

      }
      catch (Exception)
      {

        retorno = false;
      }

      return retorno;
    }

    public static List<Televisor> TraerTodos()
    {
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand comando = new SqlCommand();
      comando.CommandText = "SELECT * FROM Televisores";
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;
      List<Televisor> televisores = new List<Televisor>();
      conexion.Open();

      SqlDataReader lector = comando.ExecuteReader();


      while (lector.Read())
      {

        televisores.Add(new Televisor(lector.GetInt32(0), lector.GetString(1), lector.GetDouble(2), lector.GetInt32(3), lector.GetString(4)));
        Console.WriteLine("{0} - {1} -{2} -{3}- {4}", lector[0], lector[1], lector[2], lector[3], lector[4]);
      }
      conexion.Close();

      return televisores;


    }

    public static Televisor TraerUno(int id)
    {
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand comando = new SqlCommand();
    
      Televisor tv = null;

      comando.CommandText = string.Format("SELECT * FROM Televisores WHERE codigo = {0}", id);

      conexion.Open();
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;
      SqlDataReader lector = comando.ExecuteReader();
      
      if (lector.HasRows)
      {
        if (lector.Read())
        {
          tv = new Televisor(lector.GetInt32(0), lector.GetString(1), lector.GetDouble(2), lector.GetInt32(3), lector.GetString(4));
        }
      }

      try
      {
       
        comando.ExecuteNonQuery();
        conexion.Close();
        lector.Close();
      }
      catch (Exception e)
      {

        throw e;
      }

      return tv;
    }



  }
}
