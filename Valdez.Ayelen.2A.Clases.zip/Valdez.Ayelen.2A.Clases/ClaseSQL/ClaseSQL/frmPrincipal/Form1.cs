using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPrincipal
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    //muestra por msg box el nombre del control que invoco a este metodo
    //recibe informacion de n eventos que haya en el form
    //un manejador puede admitir varios objetos
    void MiManejadorClick(object obj, EventArgs e)
    {
      MessageBox.Show(((Control)obj).Name);
    }



    //asigno el manejador de eventos a los clicks
    //un evento puede tener varios manejadores
    private void Form1_Load(object sender, EventArgs e)
    {
      
      this.button1.Click += new EventHandler(MiManejadorClick);
      this.button1.Click += new EventHandler(ManejadorCentral);
    
      //this.button2.Click += new EventHandler(MiManejadorClick);
      //this.textBox1.Click += new EventHandler(MiManejadorClick);
      //this.Click += new EventHandler(MiOtroManejadorClick);
      //this.button1.Click += new EventHandler(CambiarFondo);

    }

    //quita el manejador de eventos del button2 y agrega el manejador al evento click del btn 1 nuevamente
    //entonces cuando clickeo en btn 1 mostrara dos veces el msg box
    void MiOtroManejadorClick(object obj, EventArgs e)
    {
      this.button2.Click -= new EventHandler(MiManejadorClick);
      this.button1.Click += new EventHandler(MiManejadorClick);

    }

    
    /// <summary>
    /// cambia el color de fondo del control que provoco el evento
    /// </summary>
    /// <param name="obj">objeto que provoco el evento</param>
    /// <param name="e">contiene info especifica acerca del evento que estamos manejando</param>
    void CambiarFondo(object obj, EventArgs e)
    {
      ((Control)obj).BackColor = Color.Aquamarine;
    }

    //quito todos los manejadores de los eventos
    private void button3_Click(object sender, EventArgs e)
    {
      this.button1.Click -= new EventHandler(MiManejadorClick);
      this.button2.Click -= new EventHandler(MiManejadorClick);
      this.textBox1.Click -= new EventHandler(MiManejadorClick);
      this.Click -= new EventHandler(MiOtroManejadorClick);
      this.button1.Click -= new EventHandler(CambiarFondo);

    }

    void ManejadorCentral(object obj, EventArgs e)
    {
   

      if(obj.Equals(this.button1))
      {
        this.button1.Click -= new EventHandler(MiManejadorClick);
        this.button1.Click -= new EventHandler(ManejadorCentral);
        this.button2.Click += new EventHandler(MiManejadorClick);
        this.button2.Click += new EventHandler(ManejadorCentral);
      }
      if(obj.Equals(this.button2))
      {
        this.button2.Click -= new EventHandler(MiManejadorClick);
        this.button2.Click -= new EventHandler(ManejadorCentral);
        this.textBox1.Click += new EventHandler(MiManejadorClick);
        this.textBox1.Click += new EventHandler(ManejadorCentral);
      }

      if(obj.Equals(this.textBox1))
      {
        this.textBox1.Click -= new EventHandler(MiManejadorClick);
        this.textBox1.Click -= new EventHandler(ManejadorCentral);
        this.button1.Click += new EventHandler(MiManejadorClick);
        this.button1.Click += new EventHandler(ManejadorCentral);

      }



    }
  }
}
