using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase04
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.Title = "EjercicioClase04";

     // Cosa a = new Cosa();
      //a.cadena = "asas";
      //a.fecha = DateTime.Now;
      //a.numero = 5;
     // Console.WriteLine(Cosa.Mostrar(a));

      Cosa d = new Cosa("hola", 5, DateTime.Now);
      Console.WriteLine(Cosa.Mostrar(d));

      Cosa b = new Cosa("aaad");
      Console.WriteLine(Cosa.Mostrar(b));



      Console.ReadLine();

      

      
    }
  }
}
