﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
   public class Class3
    {
     public   void MetodoInstancia()
        {
            try
            {
                new Class2(4, 'c');
            }
            catch (Exception e)
            {

                throw new MiException(e.Message + "Error en metodoInstancia de clase 3", e);
            }
        }
    }
}
