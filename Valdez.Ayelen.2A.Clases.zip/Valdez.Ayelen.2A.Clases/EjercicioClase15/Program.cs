using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Ej 42 de la guia

namespace ConsoleApp1
{
  class Program
  {
    static void Main(string[] args)
    {

            try
            {
                Class3 obj = new Class3();
                obj.MetodoInstancia();
            }
            catch (Exception e)
            {

                Console.WriteLine("Msj de MiException {0}", e.Message);
            }

            Console.ReadLine();
    }

   

    public static void Metodo()
    {
            throw new DivideByZeroException();
    }

  }




  }

