﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
  public  class Class1 :Exception
    {
        int nro1;
        char letra1;

        public Class1(int numero, char letra)
        {
            try
            {
                this.nro1 = numero;
                this.letra1 = letra;
                Program.Metodo();

            }

            catch(Exception e)
            {
                throw e;
            }
           
        }



    }
}
