﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
  public  class Class2 :Exception
    {
        int nro2;
        char letra2;

        public Class2(int numero, char letra)
        {
            try
            {
                this.nro2 = numero;
                this.letra2 = letra;
                new Class1(this.nro2, this.letra2);
            }
            catch (Exception e)
            {

                throw new UnaException(e.Message + "Error en el contructor de clase 2", e);
            }
        }
    }
}
