using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase07
{
    public class Tempera
    {
    private sbyte _cantidad;
    private ConsoleColor _color;
    private string marca;


    public Tempera()
    {
      this.marca = "";
      this._cantidad = 0;

    }


    }
}
