using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  class Cosa
  {
    public string cadena;
    public double numero;
    public DateTime fecha;

    public static  string Mostrar(Cosa a)
    {

      return a.Mostrar();


    }
    private string Mostrar()
    {
      return this.cadena + " " + this.numero.ToString() + " " + this.fecha.ToLongTimeString();
    }

   

    public Cosa(string cadena, double nro, DateTime fecha)
    {
      this.cadena = "SinValor";
      this.numero = 1.9;
      this.fecha = DateTime.Now;
    }

    public Cosa(string c)
    {
      this.cadena = c;
      this.numero = 1.9;
      this.fecha = DateTime.Now;
    }
  }
}
