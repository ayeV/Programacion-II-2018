using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Ejercicio 42 de la guia
namespace ConsoleApp1
{
  class Program
  {
    static void Main(string[] args)
    {
    
      
  

    }

    public static double Dividir(int numero1, int numero2)
    {
      double resultado = 0;
      try
      {
        resultado = numero1 / numero2;
      }
      catch (DivideByZeroException ex)
      {
        throw new MiException("Error al intentar dividir", "Class Program.Dividir", ex);
      }

      return resultado;
    }


  }




  }

