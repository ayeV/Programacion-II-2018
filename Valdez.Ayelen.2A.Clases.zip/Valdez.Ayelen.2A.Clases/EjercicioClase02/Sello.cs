using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  class Sello
  {
    public static string mensaje;
    public static ConsoleColor color;

    public static string Imprimir()

    {
      string cadena = "";
      
      if ((Sello.TryParse(Sello.mensaje,out cadena) == true))
      {
        cadena = ArmarFormatoMensaje();
        Sello.mensaje = cadena;
        
      }
      else
      {
        Console.WriteLine("Mensaje vacio");
      }
     
      return Sello.mensaje;

    }

    public static void Borrar()
    {
      Sello.mensaje = "";
    }

    public static void ImprimirColor()
    {
      Console.BackgroundColor = Sello.color;
      Console.WriteLine(Sello.Imprimir());
      Console.BackgroundColor = Sello.color;

    }

    private static string ArmarFormatoMensaje()
    {
      int i;
      
      int cant = Sello.mensaje.Length + 2;
      string a= "";
      string b = "";
      string c = "";
      string d = "";
        
      for(i=0;i<cant;i++)
      {
        a = a + "*";
        
      }
      c = a + "\n";
      b = "*" + Sello.mensaje + "*" + "\n";
      d = c + b;
      d = d + a;
      

      return d;
    }

    private static bool TryParse(string msj, out string msj2)
    {
       bool retorno = false;
      msj2 = "";
      if(msj.Length > 0)
      {
        msj2 = msj;
        retorno = true;
      }
      return retorno;
    }


  }
}
