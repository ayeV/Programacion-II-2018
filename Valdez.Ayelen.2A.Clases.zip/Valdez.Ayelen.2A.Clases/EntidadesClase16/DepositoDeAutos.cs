using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase16
{
  public class DepositoDeAutos
  {
    int _capacidadMaxima;
    List<Auto> _lista;

    public DepositoDeAutos(int capacidad)
    {
      this._capacidadMaxima = capacidad;
      this._lista = new List<Auto>();
    }

    #region Sobrecargas
    public static bool operator +(DepositoDeAutos d, Auto a)
    {
      bool retorno = true;
      foreach (Auto item in d._lista)
      {
        if(item == a)
        {
         
          retorno = false;
          break;
        }

      }

      if(d._lista.Count < d._capacidadMaxima)
      {
        d._lista.Add(a);
      }

      return retorno;



    }

    public static bool operator -(DepositoDeAutos d, Auto a)
    {
      bool retorno = false;
      int index = d.GetIndice(a);
      if (index != -1)
      {
        d._lista.RemoveAt(index);
        retorno = true;
      }
      return retorno;

    }

    public override string ToString()
    {
      string retorno = "";
      retorno += string.Format("Capacidad max {0}\n", this._capacidadMaxima);
      foreach (Auto item in this._lista)
      {
        retorno += item.ToString() +"\n";
       

      }

      return retorno;  
    }

    #endregion

    #region Metodos
    public bool Agregar(Auto a)
    {
      bool retorno = false;
      
      if(this +a)
      {
        retorno = true;
      }
     
      return retorno;
    }

    public bool Remover(Auto a)
    {
      bool retorno = false;
    
      if(this-a)
      {
        retorno = true;
      }

      return retorno;
    }

    private int GetIndice(Auto a)
    {
      int index = -1;
      bool existe = false;

      foreach (Auto item in this._lista)
      {
        index++;
        if (item == a)
        {
          existe = true;
          break;
        }
      }
      if (this._lista.Count == index)
      {
        index = -1;

      }
      if (!existe)
      {
        index = -1;
      }


      return index;


    }

    #endregion

  }
}
