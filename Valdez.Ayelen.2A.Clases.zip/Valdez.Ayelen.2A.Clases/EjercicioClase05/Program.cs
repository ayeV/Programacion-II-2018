using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase05
{
  class Program
  {
    static void Main(string[] args)
    {
      Tinta obj1 = new Tinta();
      //Console.WriteLine(Tinta.Mostrar(obj1));

      Tinta obj2 = new Tinta(ConsoleColor.Cyan);
      //Console.WriteLine(Tinta.Mostrar(obj2));

      Tinta obj3 = new Tinta(ConsoleColor.DarkCyan, ETipoTinta.Comun);
      //Console.WriteLine(Tinta.Mostrar(obj3));

      /*if (obj1 != obj2)
      {
        Console.WriteLine("Son distintos");
      }
      else
      {
        Console.WriteLine("Son iguales");
      }*/

      Pluma obj4 = new Pluma("marca 1",60,obj1);

      obj4 -= obj3;
      obj4 += obj3;
      Console.Write(obj4);
      

      Console.ReadLine();
    }
  }
}
