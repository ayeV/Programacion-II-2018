using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EntidadesClase16Parte2
{
 public class Deposito<T>
  {
    int _capacidadMaxima;
    List<T> _lista;

    public Deposito(int capacidad)
    {
      this._capacidadMaxima = capacidad;
      //this._lista = default(List<T>);
      this._lista = new List<T>();
    }
    #region Sobrecargas
    public static bool operator +(Deposito <T> d, T a)
    {
      bool retorno = false;
      foreach (T item in d._lista)
      {
        if (item.Equals(a))
        {

          retorno = false;
          break;
        }

      }

      if (d._lista.Count < d._capacidadMaxima)
      {
        d._lista.Add(a);
      }

      return retorno;
    }

    public static bool operator -(Deposito<T> d, T c)
    {
      bool retorno = false;
      int index = d.GetIndice(c);
      if (index != -1)
      {
        d._lista.RemoveAt(index);
        retorno = true;
      }
      return retorno;

    }

    public override string ToString()
    {
      string retorno = "";
      retorno += string.Format("Capacidad max {0}\n", this._capacidadMaxima);
      foreach (T item in this._lista)
      {
        retorno += item.ToString() + "\n";


      }

      return retorno;
    }


    #endregion

    #region Metodos
    private int GetIndice(T a)
    {
      int index = -1;
      bool existe = false;

      foreach (T item in this._lista)
      {
        index++;
        if (item.Equals(a))
        {
          existe = true;
          break;
        }
      }
      if (this._lista.Count == index)
      {
        index = -1;

      }
      if (!existe)
      {
        index = -1;
      }


      return index;


    }

    public bool Agregar(T a)
    {
      bool retorno = false;

      if (this + a)
      {
        retorno = true;
      }

      return retorno;
    }

    public bool Remover(T a)
    {
      bool retorno = false;

      if (this - a)
      {
        retorno = true;
      }

      return retorno;
    }
    #endregion



  }
}
