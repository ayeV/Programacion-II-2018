using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase07;

namespace EjercicioClase08
{
    public partial class Form1 : Form
    {
        PaletaColeccion _miPaleta;
        private List<Tempera> _temp;
        #region Constructor
        public Form1()
        {
            InitializeComponent();
            this._miPaleta = 5;
            this.groupBox1.Visible = false;
        }
        #endregion

        #region Botones
        private void btnMas_Click(object sender, EventArgs e)
        {
            FrmTempera frm = new FrmTempera();

            DialogResult rta = frm.ShowDialog();
            if (rta == DialogResult.OK)
            {
                this._miPaleta += frm.MiTemperas;
                this.textBox1.Text = (string)this._miPaleta;
            }

        }
 
        private void btnMenos_Click(object sender, EventArgs e)
        {
            string textoSeleccionado = textBox1.SelectedText;
            int index = -1;

            foreach (string item in textBox1.Lines)
            {
                if(!string.IsNullOrEmpty(textoSeleccionado))
                {
                     if (textoSeleccionado == item)
                     {
                         break;
                     }
                }
               
                index++;
            }
            FrmTempera tempera = new FrmTempera(_miPaleta[index]);
            if (tempera.ShowDialog() == DialogResult.OK)
            {
                this._miPaleta -= tempera.MiTemperas;
                this.textBox1.Text = (string)this._miPaleta;
            }
        }

        private void agregarPaletaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.textBox1.Visible = true;
            this.groupBox1.Visible = true;
            this.textBox1.Text = (string)this._miPaleta;
            this.agregarPaletaToolStripMenuItem.Enabled = false;
        }
        private void ascendenteMarcaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this._temp.Sort(Tempera.OrdenarTemperasPorMarcaAscendente);
            this.textBox1.Text = (string)_miPaleta;
        }


        #endregion

        
    }
}
