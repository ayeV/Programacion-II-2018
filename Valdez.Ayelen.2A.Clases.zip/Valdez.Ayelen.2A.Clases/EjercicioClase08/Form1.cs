using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase07;

namespace EjercicioClase08
{
    public partial class Form1 : Form
    {
        PaletaColeccion _miPaleta;
        public Form1()
        {
            InitializeComponent();
            this._miPaleta = 5;
            this.groupBox1.Visible = false;

        }

        private void btnMas_Click(object sender, EventArgs e)
        {
            
            FrmTempera frm = new FrmTempera();

            DialogResult rta = frm.ShowDialog();
            if (rta == DialogResult.OK)
            {
                this._miPaleta += frm.MiTemperas;
                textBox1.Text = (string)this._miPaleta;

            }

        }
 
        private void btnMenos_Click(object sender, EventArgs e)
        {
            string textoSeleccionado = textBox1.SelectedText;
            int index = -1;
            FrmTempera frm = new FrmTempera();
            foreach (string item in this.textBox1.Lines)
            {
                if (textoSeleccionado == item && !string.IsNullOrEmpty(textoSeleccionado) && index > -1)
                {
                    
                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        if (this._miPaleta[index] == frm.MiTemperas)
                        {
                            this._miPaleta[index] += (sbyte)((-1) * ((sbyte)frm.MiTemperas));
                        }
                        else
                        {
                            this._miPaleta[index] = null;
                        }
                        this.textBox1.Clear();
                        this.textBox1.Text = (string)this._miPaleta;
                        break;
                    }
                }
                index++;
            }
            //textoSeleccionado += " " + index.ToString();
            //MessageBox.Show(textoSeleccionado);
            

        }

        private void agregarPaletaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.textBox1.Visible = true;
            this.groupBox1.Visible = true;
            this.textBox1.Text = (string)this._miPaleta;
            this.agregarPaletaToolStripMenuItem.Enabled = false;
        }
    }
}
