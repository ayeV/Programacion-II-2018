using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase07;

namespace EjercicioClase08
{
  public partial class FrmTempera : Form
  {
    private Tempera _miTemperas;

    public Tempera MiTemperas
    {
      get { return this._miTemperas; }
    }


    public FrmTempera()
    {
    
      InitializeComponent();

      foreach (ConsoleColor color in Enum.GetValues(typeof(ConsoleColor)))
      {
        this.comboBox1.Items.Add(color);



      }
      foreach (ConsoleColor tipo in Enum.GetValues(typeof(ConsoleColor)))
      {
        this.comboBox1.Items.Add(tipo);
      }
      this.comboBox1.SelectedItem = ConsoleColor.DarkBlue;
      this.comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;


    }

    public FrmTempera(Tempera tempera) :this()
    {
      //string texto = textBox1.SelectedText;
      //int index = 0;
      //foreach(string item in this.textBox1.Lines)
      //{
      //  if(item == texto)
      //  {

      //    break;
      //  }
      //  index++;
      //}
      //this.comboBox1.SelectedItem = 


    }


    private void label2_Click(object sender, EventArgs e)
    {

    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
      
    }
    //ACEPTAR
    private void button2_Click(object sender, EventArgs e)
    {
       ConsoleColor color = (ConsoleColor)this.comboBox1.SelectedItem;
      string marca = this.textBox1.Text;
      sbyte cantidad = sbyte.Parse(this.textBox2.Text);
      this._miTemperas = new Tempera(cantidad, color, marca);
      
      this.DialogResult = DialogResult.OK;
    }

    private void FrmTempera_Load(object sender, EventArgs e)
    {

    }
    //CANCELAR
    private void button1_Click(object sender, EventArgs e)
    {
     
      this.DialogResult = DialogResult.Cancel;
      foreach(Control item in this.Controls)
      {
        if(item is TextBox || item is ComboBox)
        {
          item.Text = "";
        }
      }
      
    }
  }
}
