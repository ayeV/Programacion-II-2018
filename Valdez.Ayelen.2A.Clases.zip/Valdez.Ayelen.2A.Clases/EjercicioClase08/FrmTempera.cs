using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase07;

namespace EjercicioClase08
{
  public partial class FrmTempera : Form
  {
    private Tempera _miTemperas;

    public Tempera MiTemperas
    {
      get { return this._miTemperas; }
    }


    public FrmTempera()
    {
            this.DialogResult = DialogResult.None;

            InitializeComponent();

      foreach (ConsoleColor color in Enum.GetValues(typeof(ConsoleColor)))
      {
        this.cboColor.Items.Add(color);

      }
     
      this.cboColor.SelectedItem = ConsoleColor.DarkBlue;
      this.cboColor.DropDownStyle = ComboBoxStyle.DropDownList;


    }

    public FrmTempera(Tempera tempera) :this()
    {
            this._miTemperas = tempera;
     }


   
    //ACEPTAR
    private void btnAceptar_Click(object sender, EventArgs e)
    {
       ConsoleColor color = (ConsoleColor)this.cboColor.SelectedItem;
      string marca = this.txtMarca.Text;
      sbyte cantidad = sbyte.Parse(this.txtCant.Text);
      this._miTemperas = new Tempera(cantidad, color, marca);
      
      this.DialogResult = DialogResult.OK;
            
    }

   
    //CANCELAR
    private void btnCancelar_Click(object sender, EventArgs e)
    {
     
      this.DialogResult = DialogResult.Cancel;
      foreach(Control item in this.Controls)
      {
        if(item is TextBox || item is ComboBox)
        {
          item.Text = "";
        }
      }
      
    }

        private void FrmTempera_Load(object sender, EventArgs e)
        {

        }
    }
}
