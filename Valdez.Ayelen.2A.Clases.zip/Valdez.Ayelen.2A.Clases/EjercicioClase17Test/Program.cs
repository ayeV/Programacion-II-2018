using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EjercicioClase17;


//revisar las propiedades de IAFIP
namespace EjercicioClase17Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Deportivo a = new Deportivo(15000, "AAA", 800);
            Privado b = new Privado(4500, 500, 5);
            Carreta c = new Carreta(1200);
            Familiar d = new Familiar(45000, "DDD", 4);
            Comercial e = new Comercial(54222, 600, 80);
            Avion f = new Avion(23000, 400);

            IAFIP afipA = a;
            IARBA arbaA = a;
            IAFIP afipB = b;

            Console.WriteLine("******Datos Auto deportivo******\n");
            a.MostrarPrecio();
            a.MostrarPatente();
            Console.WriteLine("Impuesto AFIP  ${0:#.00}", Gestion.MostrarImpuestoNacional(afipA));
            Console.WriteLine("Impuesto ARBA  ${0:#.00}", Gestion.MostrarImpuestoNacional(arbaA));
            Console.WriteLine("HP {0}\n", a.PropiedadInt);


            Console.WriteLine("*****Datos Avion Privado********\n");
            b.MostrarPrecio();
            Console.WriteLine("Velocidad maxima {0}", b.PropiedadDouble);
            Console.WriteLine("Impuesto AFIP ${0:#.00}", Gestion.MostrarImpuestoNacional(afipB));
            Console.WriteLine("Valoracion {0}\n", b.Valoracion);

            Console.WriteLine("*******Datos carreta*******\n");
            IARBA arbaC = c;
            c.MostrarPrecio();
            Console.WriteLine("Impuesto ARBA ${0:#.00}\n", Gestion.MostrarImpuestoNacional(arbaC));

            Console.WriteLine("********Datos Auto Familiar**********\n");
            Console.WriteLine("No tiene impuestos");
            d.MostrarPatente();
            d.MostrarPrecio();
            Console.WriteLine("Cantidad de asientos: {0}\n", d.CantAsientos);

            Console.WriteLine("********Datos Avion Comercial**********\n");
            Console.WriteLine("No tiene impuestos");
            e.MostrarPrecio();
            Console.WriteLine("Capacidad de pasajeros: {0}\n", e.CapacidadPasajeros);

            Console.WriteLine("*******Datos Avion********\n");
            IARBA arbaF = f;
            IAFIP afipF = f;
            Console.WriteLine("Velocidad maxima: {0}", f.PropiedadDouble);
            Console.WriteLine("Impuesto ARBA {0:#.00}", Gestion.MostrarImpuestoNacional(arbaF));
            Console.WriteLine("Impuesto AFIP {0:#.00}", Gestion.MostrarImpuestoNacional(afipF));






            Console.ReadLine();
        }
    }
}
