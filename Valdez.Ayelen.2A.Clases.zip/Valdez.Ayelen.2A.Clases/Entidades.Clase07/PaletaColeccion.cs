using System;
using System.Collections.Generic;
using System.Text;
//Clase 09, Colecciones.
namespace Entidades.Clase07
{
  public class PaletaColeccion
  {
    #region Atributos
    private List<Tempera> _colores;
    private int _cantMaximaElementos;

    #endregion

    #region Constructores
    private PaletaColeccion() : this(5)
    {

    }

    private PaletaColeccion(int cantMax)
    {
      this._cantMaximaElementos = 5;
      this._colores = new List<Tempera>(this._cantMaximaElementos);
    }
    #endregion


    #region Operadores
    public static explicit operator string(PaletaColeccion p)
    {
      return p.Mostrar();
    }

    public static implicit operator PaletaColeccion(int cant)
    {
      return new PaletaColeccion(cant);

    }

    public static bool operator ==(PaletaColeccion p, Tempera t)
    {
      bool retorno = false;

      for (int i = 0; i <= p._cantMaximaElementos; i++)
      {
        if (p._colores[i] != null)
        {

          if (p._colores[i] == t)
          {
            retorno = true;
            break;
          }

        }

      }

      return retorno;

    }

    public static int operator ==(Tempera t, PaletaColeccion p)
    {
      int index=0;
      int cant = p._colores.Count;
      for (int i = 1; i <= cant; i++)
      {
          if (p._colores[i] == t)
          {
            index = i;
            break;
          }

      }
      return index;

    }
    public static int operator !=(Tempera t, PaletaColeccion p)
    {
      int index = -1;

      for (int i = 1; i < p._cantMaximaElementos; i++)
      {
        

          if (p._colores[i] != t)
          {
            index = i;
            break;
          }

        

      }
      return index;
    }

    public static bool operator !=(PaletaColeccion p, Tempera t)
    {
      return !(p == t);
    }

    public static PaletaColeccion operator +(PaletaColeccion p, Tempera t)
    {
      
      int index = t == p;
      if (index != -1)
      {
        p._colores[index] += t;
      }
      else
      {
        int cant = p._colores.Count;
        if (p._cantMaximaElementos > cant)
        {
          p._colores.Add(t);
          
        }

      }

      return p;


    }



    public static PaletaColeccion operator -(PaletaColeccion p, Tempera t)
    {
      PaletaColeccion retorno = new PaletaColeccion();
      sbyte aux1;
      sbyte aux2;
      int index = t == p;
      if (index != -1)
      {
         
         aux1 = (sbyte)p._colores[index];
         aux2 = (sbyte)t;
         if (aux1 - aux2 <= 0)
         {
            p._colores.Remove(p._colores[index]);
         }
         else
        {
          p._colores[index] += (sbyte)(aux2 * (-1));
        }

      }
      return retorno;

    }
    #endregion

    #region Metodos
    private string Mostrar()
    {

      string retorno = "Cantidad de elementos: " + this._cantMaximaElementos.ToString() + "\r\n";
      int cantidad = this._colores.Count;
      for (int i = 0; i < cantidad; i++)
      {
        if (this._colores[i] != null)
        {
          retorno += this._colores[i] + "\r\n";
        }
      }
      return retorno;


    }

    #endregion

    #region Indexador
    public Tempera this[int indice]
    {
      set
      {
        if (indice >= 0 || indice < this._cantMaximaElementos)
        {
          this._colores[indice] = value;
        }

      }

      get
      {
        Tempera temp = null;
        if (indice >= 0 || indice < this._cantMaximaElementos)
        {
          temp = this._colores[indice];
        }
        return temp;

      }

    }
    #endregion



  }
}
