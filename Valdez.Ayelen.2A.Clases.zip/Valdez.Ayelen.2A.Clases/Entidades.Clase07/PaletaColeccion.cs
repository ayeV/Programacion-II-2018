using System;
using System.Collections.Generic;
using System.Text;
//Clase 09, Colecciones.
namespace Entidades.Clase07
{
    public class PaletaColeccion
    {
        #region Atributos
        private List<Tempera> _colores;
        private int _cantMaximaElementos;

        #endregion

        #region Constructores
        

        private PaletaColeccion(int cantMax)
        {
            this._cantMaximaElementos = cantMax;
            this._colores = new List<Tempera>(this._cantMaximaElementos);
        }
        private PaletaColeccion() : this(5)
        {

        }
        #endregion


        #region Operadores
        public static explicit operator string(PaletaColeccion p)
        {
            return p.Mostrar();
        }

        public static implicit operator PaletaColeccion(int cant)
        {
            return new PaletaColeccion(cant);
        }

        public static bool operator ==(PaletaColeccion p, Tempera t)
        {
            bool retorno = false;
            
            foreach(Tempera item in p._colores)
            {
                if(item == t)
                {
                    retorno = true;
                    break;
              
                }
            }
             return retorno;

        }
        public static bool operator !=(PaletaColeccion p, Tempera t)
        {
            return !(p == t);
        }

        //Es como el ObtenerIndice
        public static int operator ==(Tempera t, PaletaColeccion p)
        {
            int index = -1;

            foreach (Tempera item in p._colores)
            {
                index++;
                if (item == t)
                {
                    break;
                }
            }
           if(p._colores.Count == index)
            {
                index = -1;
                    
            }

            return index;

        }
        public static int operator !=(Tempera t, PaletaColeccion p)
        {
            return t == p;
        }

        public static PaletaColeccion operator +(PaletaColeccion p, Tempera t)
        {

            int index = t == p;
            if (p == t)
            {
                p._colores[index] += t;
            }
            else
            {
                int cant = p._colores.Count;
                if (cant < p._cantMaximaElementos)
                {
                    p._colores.Add(t);

                }

            }

            return p;

        }


        public static PaletaColeccion operator -(PaletaColeccion p, Tempera t)
        {
            sbyte aux1;
            sbyte aux2;
            int index = t == p;
            if (p == t)
            {

                aux1 = (sbyte)p._colores[index];
                aux2 = (sbyte)t;
                if (aux1 - aux2 <= 0)
                {
                    p._colores.Remove(p._colores[index]);
                }
                else
                {
                    p._colores[index] += (sbyte)(aux2 * (-1));
                }

            }
            return p;
        }
        #endregion

        #region Metodos
        private string Mostrar()
        {

            string retorno = "Cantidad de elementos: " + this._cantMaximaElementos.ToString() + Environment.NewLine;
            int cantidad = this._colores.Count;
            for (int i = 0; i < cantidad; i++)
            {
                if (!object.Equals(this._colores[i], null))
                {
                    retorno += this._colores[i];
                }
            }

            return retorno;


        }

        #endregion

        #region Indexador
        public Tempera this[int indice]
        {
          
            get
            {
                if (indice >= 0 && indice < this._cantMaximaElementos)
                {
                    return this._colores[indice];
                }
                else
                {
                    return null;
                }
            
            }

            set
            {
                if (indice >= 0 && indice < this._cantMaximaElementos)
                {
                    this._colores[indice] = value;
                }

            }

        }
        #endregion
    }
}
