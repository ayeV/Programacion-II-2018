using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.Clase07
{
    public class Paleta
    {
        #region Atributos
        private Tempera[] _colores;
        private int _cantMaximaElementos;

        #endregion
        #region Constructores
        private Paleta() : this(5)
        {


        }

        private Paleta(int cantMax)
        {

            this._cantMaximaElementos = 5;
            this._colores = new Tempera[this._cantMaximaElementos];
        }
        #endregion

        private string Mostrar()
        {
            string retorno = "";

            retorno = retorno + this._cantMaximaElementos;
            retorno = retorno + "\n";
            foreach (Tempera item in this._colores)
            {
               if(item != null)
                  retorno += item;
            }


            return retorno;

        }

        public static explicit operator string(Paleta p)
        {
            return p.Mostrar();
        }

        public static implicit operator Paleta(int cant)
        {
            return new Paleta(cant);

        }
    //arreglar
        public static bool operator ==(Paleta p, Tempera t)
        {
            bool retorno = false;


            for (int i = 0; i < p._cantMaximaElementos; i++)
            {
                if (p._colores.GetValue(i) != null)
                { 

                    if (p._colores[i] == t)
                        retorno = true;
                    else
                        break;


                }

            }


            return retorno;

        }

        public static bool operator !=(Paleta p, Tempera t)
        {
            return !(p == t);
        }

        public static Paleta operator +(Paleta p, Tempera t)
        {
            int index = -1;
            if (p == t)
            {
                index = p.ObtenerIndice(t);
                p._colores[index] += t;

            }
            else
            {
                index = p.ObtenerIndice();
                if (index > -1)
                    p._colores[index] = t;
            }
            return p;
        }

        private int ObtenerIndice()
        {
            int index = -1;
            for (int i = 0; i < this._cantMaximaElementos; i++)
            {
                if (this._colores.GetValue(i) == null)
                {

                    index = i;
                    break;

                }

            }
            return index;

        }

        private int ObtenerIndice(Tempera t)
        {
            int index = -1;
            int i = 0;
            foreach (Tempera item in this._colores)
            {
                if (this._colores.GetValue(i) != null)
                {
                    if (t == item)
                    {
                        index = i;
                        break;
                    }
                }
                i++;
            }

            return index;
        }

    public static Paleta operator -(Paleta p, Tempera t)
    {
      Paleta retorno = new Paleta();
      sbyte aux1;
      sbyte aux2;
      int index = -1;
      if (p == t)
      {
        index = p.ObtenerIndice(t);
        aux1 = (sbyte)p._colores[index];
        aux2 = (sbyte)t;
        if(aux1-aux2 <= 0)
        {
          p._colores[index] = null;
        }
        else
        {
          p._colores[index] += (sbyte)(aux2 * (-1));
        }


      }
      return retorno;
     
    



    }

    public Tempera this[int indice]
    {
      get
      {
        if(indice >= this._cantMaximaElementos || indice <0)
        {
          return null;
        }
        else
        {
          return this._colores[indice];
        }
      }

      set
      {
        
      }



    }




    }
}
