using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase07
{
    public class Tempera
    {
        #region Atributos
        private sbyte _cantidad;
        private ConsoleColor _color;
        private string _marca;
        #endregion
        #region Propiedades
        public ConsoleColor GetColor
        {
            get { return this._color; }

        }

        public string GetMarca
        {
            get { return this._marca; }

        }
        #endregion
        #region Constructor
        public Tempera(sbyte cantidad, ConsoleColor color, string marca)
        {
            this._marca = marca;
            this._color = color;
            this._cantidad = cantidad;


        }
        #endregion


        #region Operadores
        public static implicit operator string(Tempera temp)
        {
              return temp.Mostrar();
      
        }

        public static explicit operator sbyte(Tempera temp)
        {
            return temp._cantidad;
        }
        
        public static bool operator ==(Tempera t1, Tempera t2)
        {
            bool retorno = false;
            if (!(object.Equals(t1, null)) && !(object.Equals(t2, null)))
            {
                if (t1._color == t2._color && t1._marca == t2._marca)
                {
                    retorno = true;
                }
            }
            return retorno;
        }

        public static bool operator !=(Tempera t1, Tempera t2)
        {
            return !(t1 == t2);
        }

        public static Tempera operator +(Tempera t, sbyte cant)
        {
            Tempera retorno = new Tempera((sbyte)(t._cantidad + cant), t._color, t._marca);
            return retorno;

        }

        public static Tempera operator +(Tempera t1, Tempera t2)
        {
            Tempera retorno = new Tempera(t1._cantidad, t1._color, t1._marca);

            if (t1 == t2)
            {
                retorno = retorno + t2._cantidad;
            }
            return retorno;
        }
        #endregion

        #region Metodos
        private string Mostrar()
        {
            string retorno = "";


            //retorno = retorno + "Marca:" + this._marca;
            //retorno = retorno + "    ";
            //retorno = retorno + "Cantidad:" + this._cantidad;
            //retorno = retorno + "    ";
            //retorno = retorno + "Color:" + this._color +  Environment.NewLine;

            retorno = string.Format("Marca: {0} - Cantidad: {1} - Color: {2}{3}", this._marca, this._cantidad, this._color, Environment.NewLine);

            return retorno;
        }

        public static int OrdenarTemperasPorCantidadAscendente(Tempera t1, Tempera t2)
        {
            int retorno = 0;

            if (t1._cantidad > t2._cantidad)
            {
                retorno = 1;
            }
            if (t1._cantidad < t2._cantidad)
            {
                retorno = -1;
            }

            return retorno;
        }
        public static int OrdenarTemperasPorMarcaAscendente(Tempera t1, Tempera t2)
        {
            int retorno = 0;
            if (String.Compare(t1._marca, t2._marca) < 0)
            {
                retorno = -1;
            }
            if (String.Compare(t1._marca, t2._marca) > 0)
            {
                retorno = 1;
            }

            return retorno;
        }

        #endregion
    }
}
