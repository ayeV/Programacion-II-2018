namespace EjercicioClase05
{
  class Pluma
  {
    private string _marca;
    private int _cantidad;
    private Tinta _tinta;

    #region Constructors
    public Pluma()
    {
      this._marca = "Sin marca";
      this._cantidad = 0;
      this._tinta = null;
    }

    public Pluma(string marca) : this()
    {
      this._marca = marca;

    }

    public Pluma(string marca, int cant) : this(marca)
    {
      this._cantidad = cant;
    }

    public Pluma(string marca, int cant, Tinta tinta) : this(marca,cant)
    {
      this._tinta = tinta;
    }
    #endregion

    public static implicit operator string(Pluma pluma)
    {
      return pluma.Mostrar();

    }

    private string Mostrar()
    {
      string retorno = "";

      retorno = retorno + this._marca;
      retorno = retorno + "-";
      retorno = retorno + this._cantidad;
      retorno = retorno + "-";
      retorno = retorno + Tinta.Mostrar(this._tinta);
      return retorno;
    }

    public static bool operator ==(Pluma pluma, Tinta tinta)
    {
      return pluma._tinta == tinta;
    }

    public static bool operator !=(Pluma pluma, Tinta tinta)
    {
      return !(pluma._tinta == tinta);
    }

    public static Pluma operator +(Pluma pluma, Tinta tinta)
    {

      if (pluma == tinta && pluma._cantidad <= 90)
      {

        pluma._cantidad += 10;

      }


      return pluma;
    }

    public static Pluma operator -(Pluma pluma, Tinta tinta)
    {
      if(pluma ==  tinta && pluma._cantidad >0 )
      {
        pluma._cantidad -= 10;
      }
      return pluma;
    }




  }
}
