using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clase06
{
  public partial class frmTinta : Form
  {
    public frmTinta()
    {
      InitializeComponent();
      foreach (ConsoleColor color in Enum.GetValues(typeof(ConsoleColor)))
      {
        this.comboColor.Items.Add(color);
      }
      foreach(ETipoTinta tipo in Enum.GetValues(typeof(ETipoTinta)))
      {
        this.comboTipoTinta.Items.Add(tipo);
      }
      this.comboColor.SelectedItem = ConsoleColor.DarkBlue;
      this.comboColor.DropDownStyle = ComboBoxStyle.DropDownList;
    }

    private void frmTinta_Load(object sender, EventArgs e)
    {

    }

    private void button1_Click(object sender, EventArgs e)
    {
      
      


    }

    private void label2_Click(object sender, EventArgs e)
    {

    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
  }
}
