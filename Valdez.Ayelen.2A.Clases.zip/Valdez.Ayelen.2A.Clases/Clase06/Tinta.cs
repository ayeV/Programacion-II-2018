using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase05
{
  class Tinta
  {
    private ConsoleColor _tinta;
    private ETipoTinta _tipoTinta;

    public Tinta ()
    {
      this._tinta = ConsoleColor.Blue;
      this._tipoTinta = ETipoTinta.ConBrillito;
    }

    public Tinta(ConsoleColor color) :this()
    {
      this._tinta = color;
    }

    public Tinta(ConsoleColor color, ETipoTinta tinta) :this(color)
    {
      
      this._tipoTinta = tinta;

    }


    public static string Mostrar(Tinta var)
    {
      if (!object.Equals(var, null))
        return var.Mostrar();
      else
        return "-----";
 
      
    }


    private string Mostrar()
    {
      string retorno = "";

      retorno = retorno + this._tipoTinta;
      retorno = retorno + "-";
      retorno = retorno + this._tinta;
      return retorno;
    }

    public static bool operator == (Tinta op1, Tinta op2)
    {
      bool retorno = false;
      if( !object.Equals(op1,null) && !object.Equals(op2,null))
      {
         if (op1._tinta == op2._tinta && op1._tipoTinta == op2._tipoTinta)
         {
          retorno = true;                         
          }
      }
 
        return retorno;
    }

    public static bool operator != (Tinta op1, Tinta op2)
    {
      
        return ! (op1 == op2);
      
      
    }
  }
}
