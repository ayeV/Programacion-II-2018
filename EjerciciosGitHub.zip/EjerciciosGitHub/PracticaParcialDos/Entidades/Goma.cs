﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.Threading.Tasks;

namespace Entidades {

    [Serializable]
    public class Goma : Utiles {

        public bool _soloLapiz;

        public override string Marca {

            get { return this._marca; }
            set { this._marca = value; }

        }

        public override float Precio {

            get { return this._precio; }
            set { this._precio = value; }

        }

        public Goma() : base() {

            this.Marca = "Sin marca";
            this.Precio = 5;
            this._soloLapiz = true;

        }

        public Goma(bool soloLapiz, string marca, float precio) : base(precio, marca) {

            this._soloLapiz = soloLapiz;

        }

        protected override string UtilesToString() {

            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.UtilesToString());
            sb.AppendFormat("Solo borra lapiz: {0}\n\n", this._soloLapiz == true ? "SI" : "NO");

            return sb.ToString();
        
        }

        public override string ToString() {

            return this.UtilesToString();

        }

    }

}
