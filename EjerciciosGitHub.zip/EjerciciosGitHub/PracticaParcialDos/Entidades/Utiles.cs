﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.Threading.Tasks;

namespace Entidades {

    [XmlInclude(typeof(Goma))]
    [XmlInclude(typeof(Lapicera))]
    [Serializable]
    public abstract class Utiles {

        protected float _precio;
        protected string _marca;

        public abstract float Precio { get; set; }
        public abstract string Marca { get; set; }

        public Utiles() {

            this._precio = 5;
            this._marca = "Sin marca";

        }

        public Utiles(float precio, string marca) {

            this._precio = precio;
            this._marca = marca;

        }

        protected virtual string UtilesToString() {

            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Marca: " + this._marca);
            sb.Append("Precio: " + this._precio);

            return sb.ToString();

        }

    }

}
