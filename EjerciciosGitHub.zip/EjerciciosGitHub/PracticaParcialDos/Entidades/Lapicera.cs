﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;

namespace Entidades {

    [Serializable]
    public class Lapicera : Utiles, IInterface {

        public ConsoleColor _color;
        public string _trazo;

        public override string Marca {

            get { return this._marca; }
            set { this._marca = value; }

        }

        public override float Precio {
            
            get { return this._precio; }
            set { this._precio = value; }
        
        }

        public Lapicera() : base() {

            this._color = ConsoleColor.Black;
            this._trazo = "Fino";

        }

        public Lapicera(ConsoleColor color, string trazo, string marca, float precio) : base(precio, marca) {

            this._color = color;
            this._trazo = trazo;

        }

        protected override string UtilesToString() {

            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.UtilesToString());
            sb.AppendLine("Color: " + _color.ToString());
            sb.AppendLine("Trazo: " + _trazo + "\n");

            return sb.ToString();
        
        }

        public void SerializarXml(string path) {

            TextWriter tw = new StreamWriter(path, false);

            XmlSerializer serializer = new XmlSerializer(typeof(Lapicera));

            serializer.Serialize(tw, this);

            tw.Close();

        }

        public void DeserializarXml(string path) {

            TextReader tr = new StreamReader(path);

            XmlSerializer serializer = new XmlSerializer(typeof(Lapicera));

            Console.WriteLine(((Lapicera)serializer.Deserialize(tr)).ToString());

            tr.Close();

        }

        public void SerializarBinario(string path) {

            BinaryFormatter binario = new BinaryFormatter();

            FileStream escritor = new FileStream(path, FileMode.OpenOrCreate);

            binario.Serialize(escritor, this);

            escritor.Close();

        }

        public void DeserializarBinario(string path) {

            BinaryFormatter binario = new BinaryFormatter();

            FileStream escritor = new FileStream(path, FileMode.Open);

            Console.WriteLine(((Lapicera)binario.Deserialize(escritor)).ToString());

            escritor.Close();

        }

        public override string ToString() {

            return this.UtilesToString();

        }

    }

}
