using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace Entidades.sp
{
  public class Manzana : Fruta, ISerializar, IDeserializar
  {
    protected string _provinciaOrigen;

    public string Nombre
    {
      get { return "Manzana"; }
    }


    public override bool TieneCarozo
    {
      get { return true; }
    }

    //public string Provincia
    //{
    //  get { return this._provinciaOrigen; }
    //  set { this._provinciaOrigen = value; }
    //}

    public Manzana()
    {

    }

    public Manzana(string color, double peso, string provincia) : base(color, peso)
    {
      this._provinciaOrigen = provincia;
    }



    public override string ToString()
    {
      return string.Format("{0}--" + base.FrutaToString() + "--Tiene carozo: true, Provincia {1}--", this.Nombre, this.Provincia);
    }

    public bool Xml(string archivo)
    {
      bool retorno = true;
      XmlSerializer xSerializer = new XmlSerializer(typeof(Manzana));

      try
      {
        using (XmlTextWriter xml = new XmlTextWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + archivo, null))
        {
          xSerializer.Serialize(xml, this.ToString());

        }
      }
      catch (Exception )
      {
        //throw new Exception(e.Message);
        retorno = false;
      }
      return retorno;
    }



    public bool Xml(string archivo, out Fruta datos)
    {
      bool retorno = true;
      XmlSerializer xSerializer = new XmlSerializer(typeof(Fruta));

      try
      {
        using (XmlTextReader xml = new XmlTextReader(archivo))
        {
          datos = (Fruta)xSerializer.Deserialize(xml);

        }

      }
      catch (Exception)
      {

        datos = default(Fruta);
        retorno = false;
      }

      return retorno;

    }


  }
}
