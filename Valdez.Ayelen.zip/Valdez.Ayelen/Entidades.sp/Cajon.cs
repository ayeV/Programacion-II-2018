using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
namespace Entidades.sp
{
  
  public class Cajon<T> :ISerializar
  {
    #region Atributos
    protected int _capacidad;
    protected double _precioUnitario;
    protected List<T> _elementos;
    public event DelegadoPrecio EventoPrecio;
    #endregion

    #region Propiedades
    public List<T> Elementos
    {
      get { return this._elementos; }
      set { this._elementos = value; }
    }

    public int Capacidad
    {
      get { return this._capacidad; }
      set { this._capacidad = value; }
    }

    public double PrecioTotal
    {
      get
      {
        double precioTotal = 0;
        precioTotal = this._elementos.Count * this._precioUnitario;
        if (precioTotal > 55)
        {
          this.EventoPrecio(precioTotal);
        }
        return precioTotal;
      }
    }
    #endregion

    #region Constructores

    public Cajon()
    {
      this._elementos = new List<T>();

    }
    public Cajon(int capacidad) : this()
    {
      this._capacidad = capacidad;
    }
    public Cajon(double precio, int capacidad) : this(capacidad)
    {
      this._precioUnitario = precio;
    }
    #endregion

    #region Operador

    public static Cajon<T> operator +(Cajon<T> c, T frutas)
    {
      foreach (T item in c._elementos)
      {
        if (item.Equals(frutas))
        {
          break;
        }
      }

      if (c._elementos.Count < c._capacidad)
      {
        c._elementos.Add(frutas);
      }
      else
      {
        throw new CajonLlenoException("No puede agregar mas frutas porque se supero la capacidad");
      }

      return c;
    }
    #endregion

    #region Metodos
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendFormat("Capacidad: {0}  Cant elementos: {1}  Precio total: {2}\n", this._capacidad, this._elementos.Count, this.PrecioTotal);
      foreach (T item in this._elementos)
      {
        sb.AppendLine(item.ToString());
      }

      return sb.ToString();
    }

    public bool Xml(string path)
    {
      bool retorno = true;
      XmlSerializer xser = new XmlSerializer(typeof(Cajon<T>));
      try
      {
        using (XmlTextWriter var = new XmlTextWriter(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "/Cajon.xml", Encoding.UTF8))
        {
          xser.Serialize(var, this);
        }
      }
      catch (Exception )
      {
        retorno = false;
        throw;
      }

      return retorno;
    }
    #endregion

  }
}
