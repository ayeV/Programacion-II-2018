using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
namespace Entidades.sp
{
  public class Cajon<T> :ISerializar
  {
    protected int _capacidad;
    protected List<T> _elementos;
    protected double _precioUnitario;


    public List<T> Elementos
    {
      get { return this._elementos; }
      
    }

    public double PrecioTotal
    {
      get { return this._precioUnitario * this._elementos.Count; }
    }

    //public int Capacidad
    //{
    //  get{ return this.Capacidad; }
    //  set { this._capacidad = value; }
    //}

    //public double PrecioUnitario
    //{
    //  get { return this._precioUnitario; }
    //  set { this._precioUnitario = value; }
    //}

    public Cajon()
    {
      this._elementos = new List<T>();
    }

    public Cajon(int capacidad) : this()
    {
      this._capacidad = capacidad;
    }

    public Cajon(double precio, int capacidad) : this(capacidad)
    {
      this._precioUnitario = precio;
    }


    public static Cajon<T> operator +(Cajon<T> cajon, T elemento)
    {
     // bool retorno = false;
      foreach (T item in cajon._elementos)
      {
        if (item.Equals(elemento))
        {
         // retorno = false;
          break;
        }

      }

      if (cajon._elementos.Count < cajon._capacidad)
      {
        cajon._elementos.Add(elemento);
      }

      return cajon;
    }

    public override string ToString()
    {
      string retorno = "";
      retorno += string.Format("Capacidad {0}- Cantidad de elementos {1}- Precio total {2}\n", this._capacidad, this._elementos.Count, this.PrecioTotal);
      foreach (T item in this._elementos)
      {
        retorno += item.ToString() + "\n";


      }

      return retorno;

    }

    public bool Xml(string archivo)
    {
      bool retorno = true;
      XmlSerializer xSerializer = new XmlSerializer(typeof(Cajon<T>));
      try
      {
        using (XmlTextWriter xml = new XmlTextWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + archivo, null))
        {
          xSerializer.Serialize(xml, this.ToString());

        }
      }
      catch (Exception)
      {

        retorno = false;
      }
      return retorno;
    }


  }
}
