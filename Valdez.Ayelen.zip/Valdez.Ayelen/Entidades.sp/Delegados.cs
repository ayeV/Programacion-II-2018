public delegate void DelegadoPrecio(double precio);
