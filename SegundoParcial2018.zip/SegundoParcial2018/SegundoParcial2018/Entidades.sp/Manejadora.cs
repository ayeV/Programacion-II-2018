﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Entidades.sp
{
  public  class Manejadora
    {
        

        //private void Imprimir_Cajon()
        //{
        //    try
        //    {
        //        using (var sw = new StreamWriter(String.Format("{0}/cajon_{1}.txt", Environment.CurrentDirectory, typeof(T).Name)))
        //        {
        //            sw.Write(string.Format("Precio Total {0} Fecha y hora: {1}", this.PrecioTotal, DateTime.Now.ToString("G")));
        //        }

        //    }
        //    catch (Exception e)
        //    {
        //    }


       // }
    }
}
