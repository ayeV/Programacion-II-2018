﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Entidades.sp
{
  public  class Manejadora
    {


        public void Imprimir_Cajon(string path, double precio)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(path,false))
                {
                    sw.Write(string.Format("Precio Total {0} Fecha y hora: {1}", precio, DateTime.Now.ToString("G")));
                }

            }
            catch (Exception e)
            {
            }


        }
    }
}
