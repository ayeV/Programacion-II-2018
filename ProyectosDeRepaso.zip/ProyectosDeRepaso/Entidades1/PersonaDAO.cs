﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
namespace Entidades1
{
    public class PersonaDAO
    {
        public bool Guardar(Persona persona)
        {
            bool retorno = false;
            SqlConnection connection = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand command = new SqlCommand();
            command.CommandText = string.Format("INSERT INTO Persona.dbo.personas values ('{0}', '{1}')",persona.Nombre, persona.Apellido);
            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;

            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
                retorno = true;
            }
            catch (Exception e)
            {

                retorno = false;
            }

            return retorno;
        }


        public string Leer()
        {

            SqlConnection connection = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand command = new SqlCommand();
            command.CommandText = string.Format("SELECT * FROM Persona.dbo.personas");
            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;
            StringBuilder sb = new StringBuilder();
            try
            {
                connection.Open();
                SqlDataReader lector = command.ExecuteReader();
                while (lector.Read())
                {
                    sb.AppendLine(string.Format("ID: {0}-NOMBRE: {1}-APELLIDO: {2}\n", lector[0], lector[1], lector[2]));
                }
                connection.Close();
            }
            catch (Exception e)
            {
                throw;
            }

            return sb.ToString();


        }

        public string LeerPorID(int id)
        {

            SqlConnection connection = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand command = new SqlCommand();
            command.CommandText = string.Format("SELECT FROM * Persona.dbo.personas WHERE codigo = {0}", id);
            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;
            StringBuilder sb = new StringBuilder();
            try
            {
                connection.Open();
                SqlDataReader lector = command.ExecuteReader();


                if (lector.HasRows)
                {
                    sb.AppendFormat("ID: {0}-NOMBRE: {1}-APELLIDO: {2}\n", lector[0], lector[1], lector[2]);
                }
                connection.Close();
            }
            catch (Exception e)
            {

                throw;
            }

            return sb.ToString();

        }


        public bool Modificar(Persona persona)
        {
            bool retorno = true;

            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand comando = new SqlCommand();
            comando.CommandText = string.Format("UPDATE  Persona.dbo.personas SET  nombre = '{0}', apellido = '{1}' WHERE codigo = {2}", persona.Nombre, persona.Apellido, persona.ID);
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;

            try
            {
                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception e)
            {

                retorno = false;
            }

            return retorno;

        }

        public bool Borrar(Persona persona)
        {
            bool retorno = true;
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand comando = new SqlCommand();
            comando.CommandText = string.Format("DELETE  Persona.dbo.personas WHERE codigo = {0}", persona.ID);
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;

            try
            {
                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception)
            {

                retorno = false;
            }

            return retorno;
        }



    }
}
