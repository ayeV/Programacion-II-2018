﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Entidades4
{
   public class Manejadora
    {
        public void Imprimir_Cajon(double precio)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "/CajonPrecio.txt"))
                {
                    sw.Write(string.Format("Precio total {0} Fecha: {1}", precio, DateTime.Now.ToString("G")));
                }
            }
            catch (Exception e)
            {

                throw e;
            }
        }

    }
}
