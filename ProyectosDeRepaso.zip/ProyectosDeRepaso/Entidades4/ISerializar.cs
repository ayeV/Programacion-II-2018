﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades4
{
  public  interface ISerializar
    {
        bool Xml(string path);
    }
}
