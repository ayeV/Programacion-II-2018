﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades1;
namespace FormPersona
{
    public partial class Form1 : Form
    {
        Persona p1;
        PersonaDAO pDAO;
        
        
        public Form1()
        {
            InitializeComponent();
            pDAO = new PersonaDAO();

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            p1 = new Persona(txtNombre.Text, txtApellido.Text);
            
            if (pDAO.Guardar(p1))
            {
                MessageBox.Show("Persona guardada en bd correctamente");
            }
            else
            {
                MessageBox.Show("Error al guardar la persona");
            }
            lstPersonas.Items.Add(p1.Mostrar());
            txtApellido.Text = "";
            txtNombre.Text = "";
           
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {



        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
           
        }

        private void btnLeer_Click(object sender, EventArgs e)
        {
          
            lstPersonas.Items.Add(pDAO.Leer());
        }

       
    }
}
