using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades2;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Threading;
namespace TestCartuchera
{
    public delegate List<Utiles> ObtenerBD();
    class Program
  {
    static void Main(string[] args)
    {
     

     Cartuchera<Utiles> cartuchera = new Cartuchera<Utiles>(4, "Marca1");
     Goma goma1 = new Goma("Maped", 38, true);
     Goma goma2 = new Goma("Faber Castell", 35, false);
     Lapicera lapicera1 = new Lapicera("Bic", 45, "Azul", "Fino");
     Lapicera lapicera2 = new Lapicera("Pepito", 15, "Verde", "Grueso");
     Lapicera lapicera3 = new Lapicera("vic", 5, "Rojo", "Fino");
    

      cartuchera.Add(goma1);
      cartuchera.Add(goma2);
      cartuchera.Add(lapicera1);
      cartuchera.Add(lapicera2);

      Console.WriteLine(cartuchera.ToString());


            //try
            //{
            //  cartuchera.Add(lapicera3);
            //}
            //catch (Exception)
            //{

            //  throw  new CartucheraLlenaException("No se pueden agregar mas elementos");
            ////}
            //if (cartuchera.SerializarXml("cartuchera.xml"))
            //{
            //    Console.Write("Cartuchera serializada");


            //}
            //else
            //{
            //    Console.Write("Cartuchera NO serializada");


            //}
            //if (lapicera1.SerializarXml("lapicera1.xml"))
            //{
            //    Console.WriteLine("lapicera serializada");


            //}
            //else
            //{
            //    Console.WriteLine("lapicera NO serializada");
            //}

            //if(lapicera1.DeserializarXML("lapicera1.xml"))
            //{
            //    Console.WriteLine(lapicera1.ToString());
            //}
            //else
            //{
            //    Console.WriteLine("Lapicera No deserializada");
            //}

            //cartuchera.DeserializarXml("cartuchera.xml");


            //lapicera1.SerializarXML("lapicera01.xml");
            //cartuchera.SerializarXML("cartuchera01.xml");
            //lapicera1.DeserializarXML("lapicera01.xml");

            ThreadStart childref = new ThreadStart(Metodo);

            Thread thread = new Thread(childref);

            thread.Start();
            //espera a que termine
            thread.Join();

            cartuchera.EventoPrecio += new DelegadoPrecio(cartuchera.Imprimir_Txt);
            cartuchera.CalcularPrecio();
            

            ThreadStart threadStart = new ThreadStart(Metodo1);
            Thread thread1 = new Thread(threadStart);
            thread1.Start();
            thread1.Join();

            Console.ReadLine();

    }

        public static void  Metodo()
        {
            
            ObtenerBD delegadoBD = new ObtenerBD(Cartuchera<Utiles>.ObtenerBD);
            delegadoBD();

        }

        public static void Metodo1()
        {
            DelegadoLeerArchivo delegadoLeer = new DelegadoLeerArchivo(Cartuchera<Utiles>.LeerTxt);
            Console.WriteLine(delegadoLeer());
        }
        
    }
}
