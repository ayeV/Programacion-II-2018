using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades2;
namespace TestCartuchera
{
  class Program
  {
    static void Main(string[] args)
    {
      Cartuchera<Utiles> cartuchera = new Cartuchera<Utiles>(4, "Marca1");
      Goma goma1 = new Goma("Maped", 38, true);
      Goma goma2 = new Goma("Faber Castell", 35, false);
      Lapicera lapicera1 = new Lapicera("Bic", 45, "Azul", "Fino");
      Lapicera lapicera2 = new Lapicera("Pepito", 15, "Verde", "Grueso");
      Lapicera lapicera3 = new Lapicera("vic", 5, "Rojo", "Fino");
      cartuchera.Add(goma1);
      cartuchera.Add(goma2);
      cartuchera.Add(lapicera1);
      cartuchera.Add(lapicera2);

      Console.WriteLine(cartuchera.ToString());

      //try
      //{
      //  cartuchera.Add(lapicera3);
      //}
      //catch (Exception)
      //{

      //  throw  new CartucheraLlenaException("No se pueden agregar mas elementos");
      //}
      if (cartuchera.SerializarXml("cartuchera.xml"))
      {
        Console.Write("Cartuchera serializada");
        lapicera1.SerializarXml("lapicera1.xml");

      }
      else
      {
        Console.Write("Cartuchera NO serializada");


      }
      if (lapicera1.SerializarXml("lapicera1.xml"))
      {
        Console.Write("lapicera serializada");


      }
      else
      {
        Console.Write("lapicera NO serializada");
      }

      lapicera1.DeserializarXML("lapicera1.xml");
      cartuchera.DeserializarXml("cartuchera.xml");

      //metodos de extension
      lapicera1.SerializarXML("lapicera1.xml");
      cartuchera.SerializarXML("cartuchera.xml");
      lapicera1.DeserializarXML("lapicera1.xml");


      



      Console.ReadLine();

    }
  }
}
