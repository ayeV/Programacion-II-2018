using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades2
{
  public abstract class Utiles
  {
    #region Atributos
    protected double _precio;
    protected string _marca;
    #endregion

    #region Propiedades
    public abstract double Precio { get; set; }
    public abstract string Marca { get; set; }
    #endregion

    #region Constructor
    public Utiles()
    {

    }

    public Utiles(double precio, string marca)
    {
      this._marca = marca;
      this._precio = precio;
    }
    #endregion

    #region Metodo
    public virtual string UtilesToString()
    {
      return string.Format("Marca: {0}  Precio: {1}", this._marca, this._precio);
    }
    #endregion

  }
}
