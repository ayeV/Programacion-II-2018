using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades2
{
 public interface IInterface
  {
     bool SerializarXml(string path);
    

     bool DeserializarXml(string path);
   // bool DeserializarXml(string path, out Utiles datos);



  }
}
