using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
namespace Entidades2
{
  public class Cartuchera<T> :IInterface where T : Utiles
  {
    #region Atributos
    protected string _marca;
    protected byte _capacidad;
    protected List<T> _elementos;
    #endregion

    public List<T> Elementos
    {
      get { return this._elementos; }
      set { this._elementos = value; }
    }

    #region Constructores



    Cartuchera()
    {
      this._elementos = new List<T>();
    }

    public Cartuchera(byte capacidad,string marca) : this()
    {
      this._capacidad = capacidad;
      this._marca = marca;
    }
    #endregion

    #region Operador
    public static implicit operator byte(Cartuchera<T> cartuchera)
    {
      return cartuchera._capacidad;
    }
    #endregion

    #region Metodos
    public void Add(T elemento)
    {
      foreach (T item in this._elementos)
      {
        if (item.Equals(elemento))
        {
          break;
        }

      }

      if (this._elementos.Count < this._capacidad)
      {
        this._elementos.Add(elemento);
      }
      else
      {
        throw new CartucheraLlenaException("Cartuchera llena");
      }

     
    }

    public bool Remove(T elemento)
    {
      bool retorno = false;
      foreach (T item in this._elementos)
      {
        if (item.Equals(elemento))
        {
          this._elementos.Remove(elemento);
          retorno = true;
          break;
        }
      }

      return retorno;
    }
    //No me muestra el color ni trazo de las lapiceras
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("------CARTUCHERA-----");
      sb.AppendFormat("Marca: {0}---Capacidad:{1}  ", this._marca, this._capacidad);
      sb.AppendLine("\nElementos: \n");
      foreach (T item in this._elementos)
      {
          sb.AppendLine(item.UtilesToString());
        
      }

      return sb.ToString();
    }
    //el archivo estara en blanco porque no hay ninguna propiedad publica
    public bool SerializarXml(string path)
    {
      bool retorno = true;
      XmlSerializer xSerializer = new XmlSerializer(typeof(Utiles));

      try
      {
        using (XmlTextWriter xml = new XmlTextWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "/" + path, null))
        {
          xSerializer.Serialize(xml, this);

        }
      }
      catch (Exception e)
      {


        retorno = false;
      }
      return retorno;

    }

  

   

   public bool DeserializarXml(string path)
    {
      bool retorno = true;
      XmlSerializer xSerializer = new XmlSerializer(typeof(Cartuchera<T>));

      try
      {
        using (XmlTextReader xml = new XmlTextReader(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "/" + path))
        {
          xSerializer.Deserialize(xml);

        }

      }
      catch (Exception e)
      {

       
        retorno = false;
      }

      return retorno;
    }

    #endregion


  }
}
