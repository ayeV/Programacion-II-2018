using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

namespace EjercicioClase19
{
  class Program
  {
    static void Main(string[] args)
    {
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);//este obj unicamente se podra conectar con motores de datos de tipo SQL
                                                                                       //este obj unicamente establece la conexion entre mi app y la base de datos
      List<Televisor> televisores = new List<Televisor>();


      SqlCommand comando = new SqlCommand();
      comando.CommandText = "SELECT * FROM Televisores";
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;

      conexion.Open();
      //obj lector es de solo lectura y solo avance
      SqlDataReader lector = comando.ExecuteReader();
      //Lector.read() expone los valores del registro
     
      while (lector.Read())
      {
       televisores.Add(new Televisor(lector.GetInt32(0),lector.GetString(1),lector.GetDouble(2),lector.GetInt32(3),lector.GetString(4)));
        
       Console.WriteLine("{0} - {1} -{2} -{3}- {4}",lector[0], lector[1], lector[2] , lector[3], lector[4]);
       // Console.WriteLine(lector["codigo"], lector["precio"], lector["pais"] , lector["marca"] );
      }
      //Serializar es sacarle una foto a los estados del obj
      //la clase a serializar tiene que ser publica y tener un constructor publico por default
      //Los atributos deben ser publicos o poseeer props de lectura y escritura
      XmlSerializer serializer = new XmlSerializer(typeof(List<Televisor>));

      XmlTextWriter writer = new XmlTextWriter("Televisores.xml",Encoding.UTF8);

      XmlTextReader reader = new XmlTextReader("Televisores.xml");

      serializer.Serialize(writer,televisores);
      writer.Close();

   
      List<Televisor> lista = (List<Televisor>) serializer.Deserialize(reader);

      reader.Close();
      
      conexion.Close();

      conexion.Open();
      lector = comando.ExecuteReader();
      //es la representacion en memoria de una tabla en una base de datos
      DataTable table = new DataTable("Televisores");//recibe el nombre de la tabla
      table.Load(lector);
      conexion.Close();
      table.WriteXmlSchema("Televisores_esquema");
      table.WriteXml("Televisores_dt.xml");

      DataTable tabla = new DataTable();
      tabla.ReadXmlSchema("Televisores_esquema");
      tabla.ReadXml("Televisores_dt.xml");

      Televisor nuevaTv = new Televisor(3,"Sony",1500,42,"Corea");
     if( !nuevaTv.Insertar() )
      {
        Console.Write("Error");
      }


      Console.ReadKey();

    }
  }
}
