public delegate void ActualizarNombrePorDelegado(string s);
