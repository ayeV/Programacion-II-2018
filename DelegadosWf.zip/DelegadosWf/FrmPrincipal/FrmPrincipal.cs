using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrmPrincipal
{
  public partial class FrmPrincipal : Form
  {
    public  ActualizarNombrePorDelegado MiDelegado;


    public FrmPrincipal()
    {
      InitializeComponent();
    }

    private void datosToolStripMenuItem_Click(object sender, EventArgs e)
    {
      FrmDatos datos = new FrmDatos();
      datos.Show(this);
      this.MiDelegado += datos.ActualizarNombre;

    }

    private void testDelegadosToolStripMenuItem1_Click(object sender, EventArgs e)
    {
      frmTestDelegados delegados = new frmTestDelegados();
      delegados.Show(this);
      //this.MiDelegado.Invoke("Probando");
      //this.MiDelegado("Probando");

    }
  }
}
