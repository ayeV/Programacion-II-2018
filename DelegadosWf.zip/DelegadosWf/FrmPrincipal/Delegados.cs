public delegate void ActualizarNombrePorDelegado(string s);
public delegate void MostrarAlumnoPorDelegado(Entidades.Alumno a, System.EventArgs e);
