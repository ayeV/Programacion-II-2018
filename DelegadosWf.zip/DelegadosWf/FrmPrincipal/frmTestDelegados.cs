using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrmPrincipal
{
  public partial class frmTestDelegados : Form
  {
    public frmTestDelegados()
    {
      InitializeComponent();
    }

    private void btnActualizar_Click(object sender, EventArgs e)
    {
      string s = this.textBox1.Text;
      ((FrmPrincipal)this.Owner).MiDelegado(s);
    }
  }
}
