﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
namespace EjercicioClase02
{
    class EjercicioClase02
    {
        static void Main(string[] args)
        {
            Sello.mensaje = "pepe";
            Console.WriteLine(Sello.Imprimir());
           // Sello.Borrar();

           // Console.WriteLine(Sello.mensaje);

            Sello.color = ConsoleColor.Blue;

            Sello.ImprimirColor();


            Console.ReadLine();
        }
    }
}
