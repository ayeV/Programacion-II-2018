﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    class Ejercicio01
    {
        static void Main(string[] args)

        {
            Console.Title = "Ejercicio Nro 01";
            int num;
            int i;
            int max=0;
            int min=0;
            int suma = 0;
            float promedio = 0;
            bool flag = true;
       
            for(i=0;i<5;i++)
            {
                Console.WriteLine("Ingrese nro: ",i);
                num = int.Parse(Console.ReadLine());
                
                if(flag)
                {
                    max = min = num;
                    flag = false;
                }
                if(max<num)
                {
                    max = num;
                }
                else if(min>num)
                {
                    min = num;
                }

                suma = suma + num;



            }
            promedio = (suma / (float)i);
            
            Console.WriteLine("MAX: {0}, MIN: {1}, PROMEDIO: {2:0.00}", max,min,promedio);


            Console.ReadLine();




        }

    }
}
