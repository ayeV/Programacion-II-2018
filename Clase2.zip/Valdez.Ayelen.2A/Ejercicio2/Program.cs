﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    class Ejercicio2
    {
        static void Main(string[] args)
        {
            double num;
            double cuadrado = 0;
            double cubo = 0;

            Console.WriteLine("Ingrese nro: ");
            num = double.Parse(Console.ReadLine());

            cuadrado = Math.Pow(num, 2);
            cubo = Math.Pow(num, 3);

            Console.WriteLine("El cuadrado de {0} es: {1} y su cubo: {2}", num, cuadrado, cubo);
            Console.ReadLine();

        }
    }
}
